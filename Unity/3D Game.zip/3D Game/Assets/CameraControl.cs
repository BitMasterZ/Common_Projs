﻿using UnityEngine;
using System.Collections;

public class CameraControl : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetJoystickNames ().Length == 0)return;

		if (Input.GetAxisRaw("RVertical")==1 || Input.GetAxisRaw("RVertical")==-1) {//A
			transform.Rotate(Input.GetAxisRaw("RVertical")*new Vector3(20*Mathf.PI*Time.deltaTime,0,0));
		}

	}
}
