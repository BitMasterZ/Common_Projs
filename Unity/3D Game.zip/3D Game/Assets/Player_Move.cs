﻿using UnityEngine;
using System.Collections;

public class Player_Move : MonoBehaviour {
	public KeyCode Up,Down,Left,Right,Jump;
	float MSpeed=5,RSpeed=Mathf.PI/2;
	Camera MainCam;
	public float DJSpeed,Grav;
	float JSpeed=0;
	bool Ground=false;


	// Use this for initialization
	void Start () {
		MainCam = this.GetComponent<Camera> ();
	}
	void KeyboardControls(){
		if (Input.GetKey (Up)) {
			this.transform.Translate(new Vector3(MSpeed*Time.deltaTime,0,0));
		}
		if (Input.GetKey (Down)) {
			this.transform.Translate(-new Vector3(MSpeed*Time.deltaTime,0,0));
		}
		
		if (Input.GetKey (Left)) {
			this.transform.Rotate(-new Vector3(0,RSpeed,0));
		}
		if (Input.GetKey (Right)) {
			this.transform.Rotate(new Vector3(0,RSpeed,0));
		}
		if (Input.GetKey (Jump)) {
			transform.Translate(new Vector3(0,0.11f,0));
			JSpeed=DJSpeed;
		}
	}
	void JoystickControls(){
		if (Input.GetButtonDown ("A")) {//A
			print ("A");
			transform.Translate(new Vector3(0,0.4f,0));
			JSpeed=DJSpeed;
		}
		if (Input.GetButtonDown ("B")) {//B
			print ("B");
		}
		if (Input.GetButtonDown ("X")) {//X
			print ("X");
		}
		if (Input.GetButtonDown ("Y")) {//Y
			print ("Y");
		}
		if (Input.GetButtonDown ("LB")) {//Y
			print ("LB");
		}
		if (Input.GetButtonDown ("RB")) {//Y
			print ("RB");
		}
		if (Input.GetAxisRaw("LT")==1 ) {//Y
			print ("LT");
		}
		if (Input.GetAxisRaw("RT")==1 ) {//Y
			print ("RT");
		}
		if (Input.GetAxisRaw("RHorizontal")==1 || Input.GetAxisRaw("RHorizontal")==-1) {//A

			this.transform.Rotate(Input.GetAxisRaw("RHorizontal")*new Vector3(0,RSpeed,0));
		}
		if (Input.GetAxisRaw("Vertical")==1 || Input.GetAxisRaw("Vertical")==-1) {//A
		
			this.transform.Translate(-Input.GetAxisRaw("Vertical")*new Vector3(MSpeed*Time.deltaTime,0,0));
		}
		if (Input.GetAxisRaw("Horizontal")==1 || Input.GetAxisRaw("Horizontal")==-1) {//A
			
			this.transform.Translate(-Input.GetAxisRaw("Horizontal")*new Vector3(0,0,MSpeed*Time.deltaTime));
		}

	}
	// Update is called once per frame
	void Update () {
		//MainCam.transform.rotation = transform.rotation;


		if (Input.GetJoystickNames().Length!=0) {
			JoystickControls();
		}else{
			KeyboardControls ();
		}

		if (Ground) {
			JSpeed=0;

			//transform.position = new Vector3 (transform.position.x, box.size.y+box.center.y+0.25f, transform.position.z);
		}else{
			JSpeed-=Grav*Time.deltaTime;
		}

		transform.Translate (new Vector3 (0, JSpeed * Time.deltaTime, 0));

	}
	void OnCollisionStay(Collision coll){
		if(coll.gameObject.tag!="Wall"){
			Ground = true;
		}
		if(coll.gameObject.tag=="Ceil"){
			Ground = false;
		}

	}
	void OnCollisionExit(Collision coll){
		if(coll.gameObject.tag!="Wall"){
			Ground = false;
		}


	}
}
