﻿using UnityEngine;
using System.Collections;

public class SoldierScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown(KeyCode.Alpha1))
			transform.animation.Play("idle0");
		else if(Input.GetKeyDown(KeyCode.Alpha2))
			transform.animation.Play("idle1");
		else if(Input.GetKeyDown(KeyCode.Alpha3))
			transform.animation.Play("idle2");
		else if(Input.GetKeyDown(KeyCode.Alpha4))
			transform.animation.Play("death");
	}
}
