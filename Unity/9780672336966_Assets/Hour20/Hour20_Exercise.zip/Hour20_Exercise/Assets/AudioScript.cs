﻿using UnityEngine;
using System.Collections;

public class AudioScript : MonoBehaviour {
	
	public AudioClip clip1;
	public AudioClip clip2;
	public AudioClip clip3;
	
	void Start()
	{
		audio.clip = clip1;
	}
	
	void Update () {
		if(Input.GetButtonDown("Jump"))
		{
			if(audio.isPlaying)
				audio.Stop();
			else
				audio.Play();
		}
		
		if(Input.GetKeyDown(KeyCode.L))
			audio.loop = !audio.loop; //toggles lopping
		
		if(Input.GetKeyDown(KeyCode.Alpha1))
		{
			audio.Stop();
			audio.clip = clip1;
			audio.Play();
		}
		else if(Input.GetKeyDown(KeyCode.Alpha2))
		{
			audio.Stop();
			audio.clip = clip2;
			audio.Play();
		}
		else if(Input.GetKeyDown(KeyCode.Alpha3))
		{
			audio.Stop();
			audio.clip = clip3;
			audio.Play();
		}
	}
}
