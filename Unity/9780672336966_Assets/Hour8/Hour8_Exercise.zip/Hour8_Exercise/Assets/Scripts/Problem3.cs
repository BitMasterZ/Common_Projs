using UnityEngine;
using System.Collections;

public class Problem3 : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
		int num1 = 0;
		int num2 = 1;
		int num3;
		
		print (num1);
		print (num2);
		
		for(int i = 3; i <= 20; i++)
		{
			num3 = num2 + num1;
			num1 = num2;
			num2 = num3;
			
			print (num3);
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
