using UnityEngine;
using System.Collections;

public class Problem2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
		for(int i = 1; i <= 100; i++)
		{
			if(i % 3 == 0 || i % 5 == 0)
				print ("Programming is Awesome!");
			else
				print (i);
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
