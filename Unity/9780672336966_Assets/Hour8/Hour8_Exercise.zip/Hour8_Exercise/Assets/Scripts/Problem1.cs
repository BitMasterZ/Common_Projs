using UnityEngine;
using System.Collections;

public class Problem1 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
		int sum = 0;
		for(int i = 2; i < 500; i += 2)
		{
			sum += i;
		}
		
		print (sum);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
