﻿using UnityEngine;
using System.Collections;

public class MobileLookScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		foreach(Touch touch in Input.touches)
		{
			transform.Rotate(-touch.deltaPosition.y, 0f, 0f);
		}
	}
}
