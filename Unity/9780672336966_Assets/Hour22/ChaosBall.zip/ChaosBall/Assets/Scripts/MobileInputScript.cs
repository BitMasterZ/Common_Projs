﻿using UnityEngine;
using System.Collections;

public class MobileInputScript : MonoBehaviour {

	public float speed = 15;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		float x = Input.acceleration.x * Time.deltaTime * speed;
		float z = -Input.acceleration.z * Time.deltaTime * speed;
		
		transform.Translate(x, 0f, z);
		
		foreach(Touch touch in Input.touches)
		{			
			//turning
			if(touch.position.x > Screen.width / 2)
			{
				transform.Rotate(0f, touch.deltaPosition.x * 10, 0f);
			}
		}
	}
}
