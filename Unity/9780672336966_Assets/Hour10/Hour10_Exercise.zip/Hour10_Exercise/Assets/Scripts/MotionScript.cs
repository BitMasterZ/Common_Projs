using UnityEngine;
using System.Collections;

public class MotionScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate(Input.GetAxis("Horizontal") / 2, Input.GetAxis("Vertical") / 2, 0);
	}
}
