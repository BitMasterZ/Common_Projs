﻿using UnityEngine;
using System.Collections;

public class InputScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//Cycle through the "touches" and use their properties
		//to manipulate the on screen items
		foreach(Touch touch in Input.touches)
		{
			if(touch.fingerId == 0 && gameObject.name == "Cube1")
				transform.Translate(touch.deltaPosition.x * .05F, touch.deltaPosition.y * .05F, 0F);
			if(touch.fingerId == 1 && gameObject.name == "Cube2")
				transform.Translate(touch.deltaPosition.x * .05F, touch.deltaPosition.y * .05F, 0F);
			if(touch.fingerId == 2 && gameObject.name == "Cube3")
				transform.Translate(touch.deltaPosition.x * .05F, touch.deltaPosition.y * .05F, 0F);
			
		}
	}
}
