using UnityEngine;
using System.Collections;

public class GUIScript : MonoBehaviour {
	
	public GUISkin skin;
	string labelString = "";
	string textString = "";
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI()
	{
		GUI.skin = skin; 
		textString = GUI.TextField(new Rect(5, 5, 80, 30), textString);
		if(GUI.Button(new Rect(5, 40, 80, 30), "Click Me"))
		{
			labelString = textString;
		}
		GUI.Label(new Rect(5, 75, 80, 30), labelString);
	}
}
