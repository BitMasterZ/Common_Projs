﻿using UnityEngine;
using System.Collections;

public class Destroy_Objs : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	void OnCollisionEnter2D(Collision2D coll) {
		if (coll.gameObject.tag == "DESO") {
			Animator controller=coll.gameObject.GetComponent<Animator>();
			controller.SetTrigger("Collide");
			coll.gameObject.GetComponent<BoxCollider2D>().isTrigger=true;

		}
	}

	void OnCollisionStay2D(Collision2D coll) {

		
		
	}
	void OnCollisionExit2D(Collision2D coll) {

	}
	// Update is called once per frame
	void Update () {
	
	}
}
