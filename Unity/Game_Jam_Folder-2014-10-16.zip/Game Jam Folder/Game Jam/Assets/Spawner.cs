﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {
	public double SpawnDelay=1;
	double Counter=0;
	public GameObject prefab;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Counter += Time.deltaTime;
		if (Counter > SpawnDelay) {
			Instantiate(prefab, transform.position, Quaternion.identity);
			Counter=0;
		}
	}
}
