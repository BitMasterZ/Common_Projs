﻿using UnityEngine;
using System.Collections;

public class Player_Move : MonoBehaviour {

	public float rspeed = 5f;
	public float DJumpSpeed=5f,Gravity=3f;
	BoxCollider2D bcollider;
	bool Ground=false;
	float Jspeed=0,DRSpeed=0;
	Animator anim;
	float StandX,StandY,CrawlX,CrawlY;
	double RecSpeed=2,RecCounter=0;
	public int Mode =1;
	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator> ();
		bcollider= GetComponent<BoxCollider2D> ();
		StandX = bcollider.size.x;
		StandY=bcollider.size.y;
		CrawlX = bcollider.size.y;
		CrawlY=bcollider.size.x;

		DRSpeed = rspeed;

		
	}

	void OnCollisionEnter2D(Collision2D coll) {
		if (coll.gameObject.tag == "DESO") {
			Animator controller=coll.gameObject.GetComponent<Animator>();
			controller.SetTrigger("Collide");
			coll.gameObject.GetComponent<BoxCollider2D>().isTrigger=true;
			if(DRSpeed<2){
				if(rspeed-1>=0){
					rspeed=rspeed-DRSpeed/5;
				}else{
					rspeed=0;
				}
			}else{
				if(rspeed-2>=0){
					rspeed=rspeed-2;
				}else{
					rspeed=0;
				}
			}

		}
		if (coll.gameObject.tag == "Box") {

			if(rspeed-2>=0){
				rspeed=rspeed-DRSpeed/2;
			}else{
				rspeed=0;
			}

		}

		if (coll.gameObject.tag == "Duct" || Input.GetKeyDown(KeyCode.G)) {

			Application.LoadLevel("ChaseOne");				
		}
		if (coll.gameObject.tag == "Duct2"|| Input.GetKeyDown(KeyCode.H)) {
			
			Application.LoadLevel("Win");				
		}

	}
	void OnCollisionStay2D(Collision2D coll) {
		if (coll.gameObject.tag == "Floor") {
			Ground=true;
			if(Mode==1){
				anim.SetBool("walk",true && !anim.GetBool("crawl"));
			}

		}
		if (coll.gameObject.tag == "Moveable") {
			coll.gameObject.transform.Translate(new Vector3((rspeed)*Time.deltaTime,0,0));
			Animator controller=coll.gameObject.GetComponent<Animator>();
			controller.SetBool("Collide",true);
		}


	}
	void OnCollisionExit2D(Collision2D coll) {
		if (coll.gameObject.tag == "Floor") {
			Ground=false;
			anim.SetBool("walk",false);
		}
		if (coll.gameObject.tag == "Moveable") {
			Animator controller=coll.gameObject.GetComponent<Animator>();
			controller.SetBool("Collide",false);
		}
	}



	// Update is called once per frame
	void Update () {

		if (Ground) {
			Jspeed=0;
		}else{
			Jspeed-=Gravity*Time.deltaTime;
			transform.Translate(new Vector3(0,Jspeed*Time.deltaTime,0));
		}
		anim.SetBool("grounded",Ground);
		anim.SetBool ("jump", (Jspeed != 0) && Ground);
		if (Mode == 1 && GetComponent<SpriteRenderer>().enabled) {
			transform.Translate (new Vector3 (rspeed * Time.deltaTime, 0, 0));
			transform.localScale=new Vector3(Mathf.Abs(transform.localScale.x),transform.localScale.y,transform.localScale.z);
		}

				
			
		if (Mode == 3)return;

		if(Input.GetKeyDown (KeyCode.W) || Input.GetKeyDown (KeyCode.UpArrow)) {
			if(Ground){
				Jspeed=DJumpSpeed;
				transform.Translate(new Vector3(0,0.04f,0));
				Ground=false;
				anim.SetBool ("jump", true);



			}
		}else if(Input.GetKeyUp (KeyCode.W)|| Input.GetKeyUp (KeyCode.UpArrow)){
			anim.SetBool ("jump", false);
		}
		if (Input.GetKey (KeyCode.D)|| Input.GetKey (KeyCode.RightArrow)) {
			if(Mode==1){
				transform.Translate(new Vector3(DRSpeed/4f*Time.deltaTime,0,0));
			}else{
				transform.Translate(new Vector3(4f*Time.deltaTime,0,0));
			}
			if(Ground){
				anim.SetBool("walk",true);

			}
			transform.localScale=new Vector3(Mathf.Abs(transform.localScale.x),transform.localScale.y,transform.localScale.z);
		}
		else if (Input.GetKey (KeyCode.A)|| Input.GetKey (KeyCode.LeftArrow)) {
			if(Mode==1){
				transform.Translate(new Vector3(-DRSpeed/4f*Time.deltaTime,0,0));
			}else{
				transform.Translate(new Vector3(-4f*Time.deltaTime,0,0));
			}
			if(Ground){
				anim.SetBool("walk",true);
			}
			transform.localScale=new Vector3(-Mathf.Abs(transform.localScale.x),transform.localScale.y,transform.localScale.z);
		}else{
			if(Mode!=1)anim.SetBool("walk",false);

		}


		if (Input.GetKey (KeyCode.S)|| Input.GetKey (KeyCode.DownArrow)) {
			anim.SetBool ("crawl", true);
			bcollider.size=new Vector2(CrawlX,CrawlY);
		} else if (Input.GetKeyUp (KeyCode.S)|| Input.GetKeyUp (KeyCode.DownArrow)) {
			anim.SetBool ("crawl", false);
			bcollider.size=new Vector2(StandX,StandY);
		}



		if(rspeed!=DRSpeed)RecCounter+=Time.deltaTime;
		if (RecCounter > RecSpeed) {
			rspeed=DRSpeed;
			RecCounter=0;
		}

	}
}
