﻿using UnityEngine;
using System.Collections;

public class CutScene : MonoBehaviour {
	public float XSpeed=2;
	double Counter=0;
	GameObject Hunter,Camera;
	float DXSpeed;
	bool Approach=false,MoveAway=false;
	// Use this for initialization
	void Start () {
		GetComponent<Player_Move> ().Mode = 3;
		Hunter = GameObject.FindGameObjectWithTag ("Hunter");
		DXSpeed = Hunter.GetComponent<Hunter_Move> ().XSpeed;
		Hunter.GetComponent<Hunter_Move> ().XSpeed = 0;
		Camera = GameObject.FindGameObjectWithTag ("MainCamera");
		Camera.GetComponent<Follow_Player> ().Mode = 3;
		Approach = true;

	}
	
	// Update is called once per frame
	void Update () {
		if (Camera.transform.position.x-Camera.GetComponent<Camera>().orthographicSize*2>Hunter.transform.position.x && Approach){
			Camera.transform.Translate (new Vector3 (-XSpeed * Time.deltaTime, 0, 0));
			transform.localScale = new Vector3 (-Mathf.Abs (transform.localScale.x), transform.localScale.y, transform.localScale.z);
			Counter=0;
		}else{
			Approach=false;
			
		}
		if (Counter > 3 && !MoveAway) {
			Camera.transform.Translate (new Vector3 (XSpeed * Time.deltaTime, 0, 0));
		}
		if (!MoveAway && Camera.transform.position.x>transform.position.x) {
			transform.localScale = new Vector3 (-Mathf.Abs (transform.localScale.x), transform.localScale.y, transform.localScale.z);
			Camera.GetComponent<Follow_Player> ().Mode = 1;
			GetComponent<Player_Move> ().Mode = 1;
			GetComponent<AudioSource>().Stop();
			GetComponent<AudioSource>().Play();

			Hunter.GetComponent<Hunter_Move> ().XSpeed = DXSpeed;
			this.enabled=false;
		}
		Counter+=Time.deltaTime;

	}
}
