﻿using UnityEngine;
using System.Collections;

public class Player_Audio : MonoBehaviour {
	public AudioClip Run,Jump;
	AudioSource audControl;
	Animator anim;
	// Use this for initialization
	void Start () {
		audControl = GetComponent<AudioSource> ();
		anim = GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (anim.GetBool ("walk")) {
			audControl.clip=Run;
			audControl.loop=true;
			if(!audControl.isPlaying)audControl.Play();
		} else {
			if(audControl.clip==Run){audControl.Stop();}
		}
		if (!anim.GetBool ("grounded")) {
			audControl.clip=Jump;
			audControl.loop=false;
			if(!audControl.isPlaying)audControl.Play();
		} else {
			if(audControl.clip==Jump){audControl.Stop();}
		}
	}
}
