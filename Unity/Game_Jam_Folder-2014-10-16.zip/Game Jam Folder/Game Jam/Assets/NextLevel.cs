﻿using UnityEngine;
using System.Collections;

public class NextLevel : MonoBehaviour {
	AudioSource sound;
	public string level;
	// Use this for initialization
	void Start () {
		sound = GetComponent<AudioSource> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(!sound.isPlaying){
			Application.LoadLevel(level);
	}


}
}
