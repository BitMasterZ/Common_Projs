﻿using UnityEngine;
using System.Collections;

public class Mouse_Interact : MonoBehaviour {

	public AudioClip speedingheart;
	public GameObject monitor;
	//public Animator monitorAnim;
	 public float X=380,Y=725,W= 550,H=180;
	public GameObject player1;
	public GameObject player;
	public Light lights;
	public Light red_light;
	private Animator guy;
	private SpriteRenderer playRenderer;
	private Animator mon;
	private SpriteRenderer spriteRenderer;
	private bool disappearStart = false;

	// Use this for initialization
	void Start () {
		if(monitor!=null){
	 		mon = monitor.GetComponent<Animator> ();
			guy = player.GetComponent<Animator> ();
			spriteRenderer = GetComponent <SpriteRenderer> ();
			playRenderer = player1.GetComponent <SpriteRenderer> ();
			playRenderer.enabled = false;
		}
	}

	// Update is called once per frame
	void Update () {
		if (disappearStart && spriteRenderer.color.a > 0) {
			spriteRenderer.color = new Color(1f,1f,1f,spriteRenderer.color.a - 0.05f);
		}

	}
	//void OnGUI() {
	void OnMouseDown(){
		//if (GUI.Button (new Rect (transform.position.x + X - W / 2, transform.position.y + Y - H / 2, W, H), "", GUIStyle.none) && GetComponent<SpriteRenderer>().enabled ) {

			switch(gameObject.tag){
				case "StartGame":
				disappearStart = true;
				audio.Stop();
				audio.clip = speedingheart;
				audio.volume = 1;
				audio.Play();
				Invoke ("rumble", 2.8f);
				//Animation anim=player1.GetComponent<Animator>().GetNextAnimationClipState(0);
				//anim.GetClip("Run").frameRate=1;
			

				break;
				case "Text":
			print ("asd");
				Application.LoadLevel("ChaseTwo");
				break;
				
				case "Text2":
				Application.LoadLevel("Start");
				break;
		}
		//}
			
	}
	void rumble(){

		Invoke ("flicker_off", 2f);
		Invoke ("wakeup", 2.25f);
		Invoke ("heartmonitor", 2.25f);
		Invoke ("flicker_on", 2.5f);
		Invoke ("flicker_off", 4.75f);
		Invoke ("red_on", 5f);

		}
	void flicker_off (){
				lights.enabled = false;
		}

	void flicker_on (){
		lights.enabled = true;
	}

		
	void red_on(){
				red_light.intensity = 1f;
		}
	void wakeup(){
				guy.SetTrigger ("Wake");
		Invoke ("startwalk", 4f);

		}
	void heartmonitor(){
				mon.SetTrigger ("speedup");
		Invoke ("flatline", 2f);
		}
	void flatline(){
		print ("flatline2");
		mon.SetTrigger ("unplugs");
		}

	void startwalk(){
		Destroy (player);
		playRenderer.enabled = true;
	
		//transform.Translate(new Vector3(-3f*Time.deltaTime,0,0));


		

	}
		}

