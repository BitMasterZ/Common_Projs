﻿using UnityEngine;
using System.Collections;

public class Game_Over : MonoBehaviour {

	double Counter=0;
	GameObject Blood,Text2;
	GameObject [] Text;
	//AudioSource audControl;
	// Use this for initialization
	void Start () {
		Blood=GameObject.FindGameObjectWithTag("Target");
		Text=GameObject.FindGameObjectsWithTag("Text");
		Text2=GameObject.FindGameObjectWithTag("Text2");
	//	audControl = GetComponent<AudioSource> ();
		Blood.GetComponent<SpriteRenderer> ().enabled = false;
		for (int i=0; i<Text.Length; i++) {
			Text[i].GetComponent<SpriteRenderer> ().enabled = false;
		}
		Text2.GetComponent<SpriteRenderer> ().enabled = false;
	}
	
	// Update is called once per frame
	void Update () {

		if (Counter > 3.6 && Counter<6) {
			Blood.GetComponent<SpriteRenderer> ().enabled = true;
		}else if(Counter>6){
			for (int i=0; i<Text.Length; i++) {
				Text[i].GetComponent<SpriteRenderer> ().enabled = true;
			}
			Text2.GetComponent<SpriteRenderer> ().enabled = true;
		}

		Counter += Time.deltaTime;
		//print (Counter);

	}
}
