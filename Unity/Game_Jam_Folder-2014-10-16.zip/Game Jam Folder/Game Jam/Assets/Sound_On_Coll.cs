﻿using UnityEngine;
using System.Collections;

public class Sound_On_Coll : MonoBehaviour {
	AudioSource audControl;
	float dVolume;
	// Use this for initialization
	void Start () {
		audControl = GetComponent<AudioSource> ();
		dVolume = audControl.volume;
	}
	
	// Update is called once per frame
	void OnCollisionEnter2D(Collision2D coll) {
		
		if (gameObject.tag !="DESO") {
			audControl.Play ();
			
		}

	}
	void OnTriggerEnter2D(Collider2D other) {
		
		//if (coll.gameObject.tag != "Floor") {
		audControl.Play();
		
		//}
	}
	void OnCollisionExit2D(Collision2D coll){
		if (gameObject.tag == "Moveable") {
			audControl.Pause ();
		}
		
	}
	void Update(){
		if (gameObject.tag == "Box") {
			Transform trans=GameObject.FindGameObjectWithTag("Player").transform;
			audControl.volume=1/(Mathf.Abs(transform.position.x-trans.position.x));
		}
	}
}


