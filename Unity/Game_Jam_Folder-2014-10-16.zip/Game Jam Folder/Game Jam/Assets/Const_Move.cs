﻿using UnityEngine;
using System.Collections;

public class Const_Move : MonoBehaviour {
	public float XSpeed=0,YSpeed=0;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (new Vector3 (XSpeed, YSpeed, 0)*Time.deltaTime);
	}
}
