﻿using UnityEngine;
using System.Collections;

public class Win : MonoBehaviour {

	public GameObject player;
	public GameObject monster;
	private Animator playeranim;
	//private Animator monsteranim;
	private SpriteRenderer monsterRend;
	BoxCollider2D bcollider;
	float StandX,StandY,CrawlX,CrawlY;
	// Use this for initialization
	void Start () {
		playeranim = player.GetComponent<Animator> ();
		//monsteranim = monster.GetComponent<Animator> ();
		monsterRend = monster.GetComponent<SpriteRenderer> ();
		bcollider= player.GetComponent<BoxCollider2D> ();
		StandX = bcollider.size.x;
		StandY=bcollider.size.y;
		CrawlX = bcollider.size.y;
		CrawlY=bcollider.size.x;

		monsterRend.enabled = false;
		playeranim.SetBool ("crawl", true);
		bcollider.size=new Vector2(CrawlX,CrawlY);
		Invoke ("stand", 1.5f);

	}
	
	// Update is called once per frame
	void Update () {


	}

	void stand(){
		playeranim.SetBool("crawl", false);
		playeranim.SetBool ("walk", false);
		bcollider.size=new Vector2(StandX,StandY);
		player.GetComponent<Player_Move> ().rspeed = 0;
		player.GetComponent<Player_Move> ().Mode = 2;
		playeranim.SetTrigger ("celebrate");
		Invoke ("monsterfunc", 1.5f);
		}
	void monsterfunc (){
		monsterRend.enabled = true;
		Invoke ("nextlevel", 1.25f);
		}

	void nextlevel(){
		Application.LoadLevel ("Game Over");

		}
}

