﻿using UnityEngine;
using System.Collections;

public class Follow_Player : MonoBehaviour {
	public int Mode=1;
	public float MSpeed=4f;
	public GameObject Player,Hunter;
	public Light dark;
	float dIntensity,nIntensity;
	// Use this for initialization
	void Start () {
		//Player=GameObject.FindGameObjectWithTag("Player");
		transform.Translate(Player.transform.position);
		dark = GetComponent<Light> ();
		dIntensity=dark.intensity;
	}
	
	// Update is called once per frame
	void Update () {

		switch (Mode) {
			case 0:
			break;
			case 1://Chase
			transform.Translate(new Vector3(MSpeed*Time.deltaTime,0,0));
				break;
			case 2://Normal
			Vector3 diff=new Vector3(Player.transform.position.x-transform.position.x,Player.transform.position.y-transform.position.y,0);
				transform.Translate(diff);
				break;
		}

		if (Hunter != null) {
			dark.intensity=(Player.transform.position.x-Hunter.transform.position.x)*dIntensity/10;
		}
	}
}
