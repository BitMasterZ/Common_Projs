﻿using UnityEngine;
using System.Collections;

public class Hunter_Move : MonoBehaviour {
	public float XSpeed=0f;
	public GameObject Player;
	AudioSource audControl;
	float dVolume;
	// Use this for initialization
	void Start () {
		//Player = GameObject.FindGameObjectWithTag ("Player");
		audControl = GetComponent<AudioSource> ();
		dVolume = audControl.volume;
	}

	void OnCollisionEnter2D(Collision2D coll) {
		if (coll.gameObject.tag == "DESO") {
			Animator controller=coll.gameObject.GetComponent<Animator>();
			controller.SetTrigger("Collide");
			//coll.gameObject.GetComponent<BoxCollider2D>().isTrigger=true;
			Destroy(coll.gameObject);
		}
		if (coll.gameObject.tag == "Moveable") {
			Animator controller=coll.gameObject.GetComponent<Animator>();
			controller.SetTrigger("Collide");
			//coll.gameObject.GetComponent<BoxCollider2D>().isTrigger=true;
			Destroy(coll.gameObject);
		}
		if (coll.gameObject.tag == "Player") {
			Application.LoadLevel("Game Over");
		}
	}
	// Update is called once per frame
	void Update () {
		//print (Player.transform.position);
		transform.Translate (new Vector3 (XSpeed, 0, 0) * Time.deltaTime);
		audControl.volume = 2/ ((Player.transform.position.x - transform.position.x)*dVolume) ;
	}
}
