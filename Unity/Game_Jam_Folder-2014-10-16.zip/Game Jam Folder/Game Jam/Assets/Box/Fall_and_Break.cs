﻿using UnityEngine;
using System.Collections;

public class Fall_and_Break : MonoBehaviour {
	public float FallSpeed=0;
	Animator animControl;
	double Counter=0,Delay=0.5;
	bool Destroyed=false;
	//AudioSource audControl;
	// Use this for initialization
	void Start () {
		animControl = GetComponent<Animator> ();
	}
	void OnCollisionEnter2D(Collision2D coll) {
		animControl.SetBool ("Collide",true);
		Destroyed = true;
		//audControl=GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		if(!animControl.GetBool("Collide"))transform.Translate (new Vector3 (0,-FallSpeed*Time.deltaTime,0));
		//transform.Rotate (new Vector3(0, 0, -5));
		if(Counter>Delay ){Destroy (this.gameObject);}
		if (Destroyed) {Counter += Time.deltaTime;}
	}
}
